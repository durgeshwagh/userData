import { Injectable } from '@angular/core';
 import{ HttpClient} from '@angular/common/http'
import { Subject, map } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class UserService {

      loginData = new Subject ;
     
    baseUrl = 'https://gorest.co.in/public-api/users'
  constructor( private http : HttpClient) { }

    getUsers(){
     return  this.http.get(this.baseUrl)
      
    }
     listOfPost( id:any){
        return this.http.get(`https://gorest.co.in/public-api/users/${id}`)
     }
     listOfComments(postid:any){
       return this.http.get(`https://gorest.co.in/public-api/posts/${postid}`)
     }
}
