import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
     loginForm ! : FormGroup ;
       constructor( private fb : FormBuilder , private router : Router , private _userService : UserService ){}
       

       ngOnInit(): void { 
           this.loginForm =  this.fb.group({
            username: ['', Validators.compose([Validators.required])],
            password : ['', Validators.compose([Validators.required, Validators.email])]
           })
       }

     onSubmit(){
         
      const data =  this.loginForm.value ;
       console.log( data);
       localStorage.setItem('userLogin', data)
       this.router.navigate(['/user/user-list'])
      this._userService.loginData.next(data)
        
     }
}
