import { Component, OnInit } from '@angular/core';
import { delay, map } from 'rxjs';
import { UserService } from 'src/app/services/user.service';
 
@Component({
  selector: 'app-users-list',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.css']
})
export class UsersListComponent implements OnInit {
  UserData:any;
  onshow= false ;
   CommentData:any;
   postData : any 
   constructor(private _userService : UserService){}

     
  ngOnInit(){
       this._userService.getUsers().subscribe((resp)=>{
         console.log( resp)
         setTimeout(()=>{
          this.UserData = resp ; 
         } , 2000)     
      
       console.log(this.UserData)
       })


  
  }


  ShowDetails(id:any){
    this._userService.listOfComments(id).subscribe((resp)=>{
      console.log( resp)
      this.CommentData = resp
     })

     this._userService.listOfPost(id).subscribe((resp)=>{
      console.log( resp) 
      this.postData =  resp ;
     })
     this.onshow = true ;
  }
}
